import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))  # DON'T CHANGE THIS !!!

from flask import Flask, render_template, jsonify, request, session, redirect, url_for
from src.models.models import db, BankUser, BankDeposit, BankOperationLog
from datetime import datetime, timedelta
import secrets
import decimal
from flask.json.provider import DefaultJSONProvider

# 尝试导入dotenv，如果安装了的话
try:
    from dotenv import load_dotenv
    load_dotenv()  # 加载.env文件中的环境变量
except ImportError:
    pass  # 如果没有安装dotenv，就跳过

app = Flask(__name__, 
            template_folder='templates',  # 明确指定模板目录
            static_folder='static')       # 明确指定静态文件目录

app.config['SECRET_KEY'] = secrets.token_hex(16)
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(hours=2)
# 直接使用您提供的数据库连接信息
app.config['SQLALCHEMY_DATABASE_URI'] = "mysql+pymysql://root:123456@localhost:3306/grouponep"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

# 自定义JSON编码器处理Decimal类型 - 修复Flask 3.x兼容性问题
class CustomJSONProvider(DefaultJSONProvider):
    def default(self, obj):
        if isinstance(obj, decimal.Decimal):
            return float(obj)
        return super().default(obj)

app.json_provider_class = CustomJSONProvider

# 注册蓝图
from src.routes.auth import auth_bp
from src.routes.account import account_bp
from src.routes.admin import admin_bp

app.register_blueprint(auth_bp)
app.register_blueprint(account_bp)
app.register_blueprint(admin_bp)

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('account_bp.dashboard'))
    return render_template('index.html')

# 新增：修改密码页面路由
@app.route('/change_password_page')
def change_password_page():
    if 'user_id' not in session:
        return redirect(url_for('index'))
    return render_template('change_password.html')

@app.route('/init_db')
def init_db():
    try:
        db.create_all()
        
        # 检查是否已存在管理员账户
        admin = BankUser.query.filter_by(ID='admin').first()
        if not admin:
            # 创建管理员账户
            admin = BankUser(
                ID='admin',
                userName='系统管理员',
                userPassword='admin123',
                firstTime=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                idNumber='000000000000000000',
                accountBalance=0.00,
                is_admin=True
            )
            db.session.add(admin)
            db.session.commit()
            
            # 记录管理员账户创建日志
            log = BankOperationLog(
                operationType='系统初始化',
                operationTime=datetime.now(),
                accountID='admin',
                operationDetails='创建管理员账户',
                operationResult='成功'
            )
            db.session.add(log)
            db.session.commit()
        
        return jsonify({'message': '数据库初始化成功'}), 200
    except Exception as e:
        return jsonify({'error': f'数据库初始化失败: {str(e)}'}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
