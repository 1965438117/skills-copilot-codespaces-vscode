from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class BankUser(db.Model):
    __tablename__ = 'bank_user'
    
    ID = db.Column(db.String(10), primary_key=True)
    userName = db.Column(db.String(50), nullable=False)
    userPassword = db.Column(db.String(50), nullable=False)
    firstTime = db.Column(db.String(20), nullable=False)
    idNumber = db.Column(db.String(18), nullable=False)
    accountBalance = db.Column(db.DECIMAL(15, 2), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)  # 新增管理员标识字段
    
    deposits = db.relationship('BankDeposit', backref='user', lazy=True, 
                              foreign_keys='BankDeposit.accountID')
    logs = db.relationship('BankOperationLog', backref='user', lazy=True)
    
    def __repr__(self):
        return f'<BankUser {self.ID}>'
    
    def to_dict(self):
        return {
            'ID': self.ID,
            'userName': self.userName,
            'firstTime': self.firstTime,
            'idNumber': self.idNumber,
            'accountBalance': float(self.accountBalance),
            'is_admin': self.is_admin
        }


class BankDeposit(db.Model):
    __tablename__ = 'bank_deposit'
    
    transactionID = db.Column(db.Integer, primary_key=True, autoincrement=True)
    accountID = db.Column(db.String(10), db.ForeignKey('bank_user.ID'), nullable=False)
    transactionType = db.Column(db.String(20), nullable=False)
    transactionAmount = db.Column(db.DECIMAL(15, 2), nullable=False)
    transactionDate = db.Column(db.DateTime, nullable=False, default=datetime.now)
    relatedAccount = db.Column(db.String(10), db.ForeignKey('bank_user.ID'), nullable=True)
    balanceAfter = db.Column(db.DECIMAL(15, 2), nullable=False)
    
    related_user = db.relationship('BankUser', foreign_keys=[relatedAccount], backref='related_transactions', lazy=True)
    
    def __repr__(self):
        return f'<BankDeposit {self.transactionID}>'
    
    def to_dict(self):
        return {
            'transactionID': self.transactionID,
            'accountID': self.accountID,
            'transactionType': self.transactionType,
            'transactionAmount': float(self.transactionAmount),
            'transactionDate': self.transactionDate.strftime('%Y-%m-%d %H:%M:%S'),
            'relatedAccount': self.relatedAccount,
            'balanceAfter': float(self.balanceAfter)
        }


class BankOperationLog(db.Model):
    __tablename__ = 'bank_operation_log'
    
    logID = db.Column(db.Integer, primary_key=True, autoincrement=True)
    operationType = db.Column(db.String(50), nullable=False)
    operationTime = db.Column(db.DateTime, nullable=False, default=datetime.now)
    accountID = db.Column(db.String(10), db.ForeignKey('bank_user.ID'), nullable=False)
    operationDetails = db.Column(db.Text, nullable=True)
    operationResult = db.Column(db.String(20), nullable=False)
    
    def __repr__(self):
        return f'<BankOperationLog {self.logID}>'
    
    def to_dict(self):
        return {
            'logID': self.logID,
            'operationType': self.operationType,
            'operationTime': self.operationTime.strftime('%Y-%m-%d %H:%M:%S'),
            'accountID': self.accountID,
            'operationDetails': self.operationDetails,
            'operationResult': self.operationResult
        }
