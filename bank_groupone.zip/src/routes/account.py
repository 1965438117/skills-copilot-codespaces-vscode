from flask import Blueprint, request, jsonify, session
from src.models.models import db, BankUser, BankDeposit
from datetime import datetime
from sqlalchemy import text

account_bp = Blueprint('account_bp', __name__)

@account_bp.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return jsonify({'error': '未登录'}), 401
    return render_template('dashboard.html')

@account_bp.route('/balance')
def get_balance():
    if 'user_id' not in session:
        return jsonify({'error': '未登录'}), 401
    
    user_id = session['user_id']
    user = BankUser.query.filter_by(ID=user_id).first()
    
    if not user:
        return jsonify({'error': '用户不存在'}), 404
    
    return jsonify({
        'accountID': user.ID,
        'accountBalance': float(user.accountBalance)
    })

@account_bp.route('/deposit', methods=['POST'])
def deposit():
    if 'user_id' not in session:
        return jsonify({'error': '未登录'}), 401
    
    data = request.get_json()
    if not data or 'amount' not in data:
        return jsonify({'error': '参数错误'}), 400
    
    amount = float(data['amount'])
    user_id = session['user_id']
    
    # 调用存款存储过程
    try:
        # 准备调用存储过程
        result = db.session.execute(
            text("CALL sp_deposit(:account_id, :amount, @success, @message, @new_balance)"),
            {"account_id": user_id, "amount": amount}
        )
        
        # 获取存储过程的输出参数
        result = db.session.execute(text("SELECT @success AS success, @message AS message, @new_balance AS new_balance"))
        proc_result = result.fetchone()
        
        if proc_result.success:
            return jsonify({
                'success': True,
                'amount': amount,
                'newBalance': float(proc_result.new_balance)
            })
        else:
            return jsonify({'error': proc_result.message}), 400
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'存款失败: {str(e)}'}), 500

@account_bp.route('/withdraw', methods=['POST'])
def withdraw():
    if 'user_id' not in session:
        return jsonify({'error': '未登录'}), 401
    
    data = request.get_json()
    if not data or 'amount' not in data:
        return jsonify({'error': '参数错误'}), 400
    
    amount = float(data['amount'])
    user_id = session['user_id']
    
    # 调用取款存储过程
    try:
        # 准备调用存储过程
        result = db.session.execute(
            text("CALL sp_withdraw(:account_id, :amount, @success, @message, @new_balance)"),
            {"account_id": user_id, "amount": amount}
        )
        
        # 获取存储过程的输出参数
        result = db.session.execute(text("SELECT @success AS success, @message AS message, @new_balance AS new_balance"))
        proc_result = result.fetchone()
        
        if proc_result.success:
            return jsonify({
                'success': True,
                'amount': amount,
                'newBalance': float(proc_result.new_balance)
            })
        else:
            return jsonify({'error': proc_result.message}), 400
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'取款失败: {str(e)}'}), 500

@account_bp.route('/transfer', methods=['POST'])
def transfer():
    if 'user_id' not in session:
        return jsonify({'error': '未登录'}), 401
    
    data = request.get_json()
    if not data or 'amount' not in data or 'toAccountID' not in data:
        return jsonify({'error': '参数错误'}), 400
    
    amount = float(data['amount'])
    from_account_id = session['user_id']
    to_account_id = data['toAccountID']
    
    # 调用转账存储过程
    try:
        # 准备调用存储过程
        result = db.session.execute(
            text("CALL sp_transfer(:from_account_id, :to_account_id, :amount, @success, @message, @new_balance)"),
            {"from_account_id": from_account_id, "to_account_id": to_account_id, "amount": amount}
        )
        
        # 获取存储过程的输出参数
        result = db.session.execute(text("SELECT @success AS success, @message AS message, @new_balance AS new_balance"))
        proc_result = result.fetchone()
        
        if proc_result.success:
            return jsonify({
                'success': True,
                'amount': amount,
                'toAccount': to_account_id,
                'newBalance': float(proc_result.new_balance)
            })
        else:
            return jsonify({'error': proc_result.message}), 400
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'转账失败: {str(e)}'}), 500

@account_bp.route('/transactions')
def get_transactions():
    if 'user_id' not in session:
        return jsonify({'error': '未登录'}), 401
    
    user_id = session['user_id']
    
    try:
        transactions = BankDeposit.query.filter_by(accountID=user_id).order_by(BankDeposit.transactionDate.desc()).all()
        
        result = []
        for transaction in transactions:
            result.append({
                'transactionID': transaction.transactionID,
                'transactionType': transaction.transactionType,
                'transactionAmount': float(transaction.transactionAmount),
                'transactionDate': transaction.transactionDate.strftime('%Y-%m-%d %H:%M:%S'),
                'relatedAccount': transaction.relatedAccount,
                'balanceAfter': float(transaction.balanceAfter)
            })
        
        return jsonify({'transactions': result})
    except Exception as e:
        return jsonify({'error': f'获取交易记录失败: {str(e)}'}), 500

# 导入render_template，确保dashboard路由可以正常工作
from flask import render_template
