from flask import Blueprint, request, jsonify, session, render_template, redirect, url_for
from src.models.models import db, BankUser, BankOperationLog
from datetime import datetime
import json

admin_bp = Blueprint('admin_bp', __name__)

# 检查管理员权限的装饰器
def admin_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            if request.headers.get('Content-Type') == 'application/json':
                return jsonify({'error': '请先登录'}), 401
            return redirect(url_for('index'))
        
        if not session.get('is_admin', False):
            if request.headers.get('Content-Type') == 'application/json':
                return jsonify({'error': '无管理员权限'}), 403
            return redirect(url_for('account_bp.dashboard'))
        
        return f(*args, **kwargs)
    return decorated_function

@admin_bp.route('/admin/dashboard')
@admin_required
def admin_dashboard():
    return render_template('admin_dashboard.html')

@admin_bp.route('/admin/logs')
@admin_required
def admin_logs():
    return render_template('admin_logs.html')

@admin_bp.route('/api/admin/stats')
@admin_required
def get_admin_stats():
    try:
        # 获取用户总数
        user_count = BankUser.query.filter_by(is_admin=False).count()
        
        # 获取系统总余额
        total_balance_result = db.session.execute(
            "SELECT SUM(accountBalance) FROM bank_user WHERE is_admin = 0"
        ).scalar()
        total_balance = float(total_balance_result) if total_balance_result else 0
        
        # 获取今日交易笔数
        today = datetime.now().strftime('%Y-%m-%d')
        today_transactions_count = db.session.execute(
            "SELECT COUNT(*) FROM bank_deposit WHERE DATE(transactionDate) = :today",
            {"today": today}
        ).scalar()
        
        # 获取今日操作日志数
        today_logs_count = db.session.execute(
            "SELECT COUNT(*) FROM bank_operation_log WHERE DATE(operationTime) = :today",
            {"today": today}
        ).scalar()
        
        return jsonify({
            'userCount': user_count,
            'totalBalance': total_balance,
            'todayTransactionsCount': today_transactions_count,
            'todayLogsCount': today_logs_count
        }), 200
    except Exception as e:
        return jsonify({'error': f'获取统计数据失败: {str(e)}'}), 500

@admin_bp.route('/api/admin/users')
@admin_required
def get_users():
    try:
        # 获取所有普通用户
        users = BankUser.query.filter_by(is_admin=False).all()
        
        return jsonify({
            'users': [{
                'ID': user.ID,
                'userName': user.userName,
                'firstTime': user.firstTime,
                'accountBalance': float(user.accountBalance)
            } for user in users]
        }), 200
    except Exception as e:
        return jsonify({'error': f'获取用户列表失败: {str(e)}'}), 500

@admin_bp.route('/api/admin/logs')
@admin_required
def get_logs():
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        account_id = request.args.get('account_id')
        operation_type = request.args.get('operation_type')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        # 构建查询
        query = BankOperationLog.query
        
        # 应用筛选条件
        if account_id:
            query = query.filter(BankOperationLog.accountID == account_id)
        if operation_type:
            query = query.filter(BankOperationLog.operationType == operation_type)
        if start_date:
            query = query.filter(BankOperationLog.operationTime >= f"{start_date} 00:00:00")
        if end_date:
            query = query.filter(BankOperationLog.operationTime <= f"{end_date} 23:59:59")
        
        # 分页
        pagination = query.order_by(BankOperationLog.operationTime.desc()).paginate(page=page, per_page=per_page)
        logs = pagination.items
        
        # 获取所有操作类型（用于筛选）
        operation_types = db.session.query(BankOperationLog.operationType).distinct().all()
        operation_types = [op[0] for op in operation_types]
        
        return jsonify({
            'logs': [{
                'logID': log.logID,
                'operationType': log.operationType,
                'operationTime': log.operationTime.strftime('%Y-%m-%d %H:%M:%S'),
                'accountID': log.accountID,
                'operationDetails': log.operationDetails,
                'operationResult': log.operationResult
            } for log in logs],
            'current_page': page,
            'pages': pagination.pages,
            'total': pagination.total,
            'operation_types': operation_types
        }), 200
    except Exception as e:
        return jsonify({'error': f'获取日志数据失败: {str(e)}'}), 500
