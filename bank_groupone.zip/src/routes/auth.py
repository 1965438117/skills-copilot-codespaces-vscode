from flask import Blueprint, request, jsonify, session, render_template, redirect, url_for
from src.models.models import db, BankUser, BankOperationLog
from datetime import datetime
import random
import string

auth_bp = Blueprint('auth_bp', __name__)

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    if not data or 'ID' not in data or 'userPassword' not in data:
        return jsonify({'error': '参数错误'}), 400
    
    account_id = data['ID']
    password = data['userPassword']
    
    user = BankUser.query.filter_by(ID=account_id).first()
    
    if not user:
        return jsonify({'error': '账号不存在'}), 404
    
    if user.userPassword != password:
        return jsonify({'error': '密码错误'}), 401
    
    # 登录成功，设置会话
    session['user_id'] = user.ID
    session['is_admin'] = user.is_admin
    session.permanent = True
    
    # 记录登录日志
    log = BankOperationLog(
        operationType='用户登录',
        operationTime=datetime.now(),
        accountID=user.ID,
        operationDetails=f'用户 {user.userName} 登录系统',
        operationResult='成功'
    )
    db.session.add(log)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'user': {
            'ID': user.ID,
            'userName': user.userName,
            'is_admin': user.is_admin
        }
    })

@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    if not data or 'userName' not in data or 'idNumber' not in data or 'userPassword' not in data:
        return jsonify({'error': '参数错误'}), 400
    
    user_name = data['userName']
    id_number = data['idNumber']
    password = data['userPassword']
    
    # 检查身份证号是否已被注册
    existing_user = BankUser.query.filter_by(idNumber=id_number).first()
    if existing_user:
        return jsonify({'error': '该身份证号已被注册'}), 400
    
    # 生成账号（8位随机数字）
    while True:
        account_id = ''.join(random.choices(string.digits, k=8))
        if not BankUser.query.filter_by(ID=account_id).first():
            break
    
    # 创建新用户
    new_user = BankUser(
        ID=account_id,
        userName=user_name,
        userPassword=password,
        firstTime=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        idNumber=id_number,
        accountBalance=0.00,
        is_admin=False
    )
    
    try:
        db.session.add(new_user)
        db.session.commit()
        
        # 记录注册日志
        log = BankOperationLog(
            operationType='用户注册',
            operationTime=datetime.now(),
            accountID=account_id,
            operationDetails=f'新用户 {user_name} 注册',
            operationResult='成功'
        )
        db.session.add(log)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'user': {
                'ID': account_id,
                'userName': user_name
            }
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'注册失败: {str(e)}'}), 500

@auth_bp.route('/logout')
def logout():
    if 'user_id' in session:
        user_id = session['user_id']
        
        # 记录登出日志
        log = BankOperationLog(
            operationType='用户登出',
            operationTime=datetime.now(),
            accountID=user_id,
            operationDetails=f'用户登出系统',
            operationResult='成功'
        )
        db.session.add(log)
        db.session.commit()
        
        # 清除会话
        session.pop('user_id', None)
        session.pop('is_admin', None)
    
    return redirect(url_for('index'))

@auth_bp.route('/check_session')
def check_session():
    if 'user_id' not in session:
        return jsonify({'authenticated': False})
    
    user_id = session['user_id']
    user = BankUser.query.filter_by(ID=user_id).first()
    
    if not user:
        session.pop('user_id', None)
        session.pop('is_admin', None)
        return jsonify({'authenticated': False})
    
    return jsonify({
        'authenticated': True,
        'user': {
            'ID': user.ID,
            'userName': user.userName,
            'is_admin': user.is_admin
        }
    })

# 新增：修改密码功能
@auth_bp.route('/change_password', methods=['POST'])
def change_password():
    if 'user_id' not in session:
        return jsonify({'error': '未登录'}), 401
    
    data = request.get_json()
    if not data or 'oldPassword' not in data or 'newPassword' not in data:
        return jsonify({'error': '参数错误'}), 400
    
    user_id = session['user_id']
    old_password = data['oldPassword']
    new_password = data['newPassword']
    
    # 验证用户
    user = BankUser.query.filter_by(ID=user_id).first()
    if not user:
        return jsonify({'error': '用户不存在'}), 404
    
    # 验证旧密码
    if user.userPassword != old_password:
        # 记录失败日志
        log = BankOperationLog(
            operationType='修改密码',
            operationTime=datetime.now(),
            accountID=user_id,
            operationDetails='修改密码失败：旧密码验证错误',
            operationResult='失败'
        )
        db.session.add(log)
        db.session.commit()
        
        return jsonify({'error': '旧密码错误'}), 401
    
    # 更新密码
    try:
        user.userPassword = new_password
        db.session.commit()
        
        # 记录成功日志
        log = BankOperationLog(
            operationType='修改密码',
            operationTime=datetime.now(),
            accountID=user_id,
            operationDetails='用户成功修改密码',
            operationResult='成功'
        )
        db.session.add(log)
        db.session.commit()
        
        return jsonify({'success': True, 'message': '密码修改成功'})
    except Exception as e:
        db.session.rollback()
        
        # 记录错误日志
        log = BankOperationLog(
            operationType='修改密码',
            operationTime=datetime.now(),
            accountID=user_id,
            operationDetails=f'修改密码失败：{str(e)}',
            operationResult='失败'
        )
        db.session.add(log)
        db.session.commit()
        
        return jsonify({'error': f'密码修改失败: {str(e)}'}), 500
